/*     */ package me.venom.moneymobs.metrics;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.Proxy;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.net.URLEncoder;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.configuration.InvalidConfigurationException;
/*     */ import org.bukkit.configuration.file.YamlConfiguration;
/*     */ import org.bukkit.configuration.file.YamlConfigurationOptions;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.plugin.PluginDescriptionFile;
/*     */ import org.bukkit.scheduler.BukkitScheduler;
/*     */ import org.bukkit.scheduler.BukkitTask;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Metrics
/*     */ {
/*     */   private static final int REVISION = 7;
/*     */   private static final String BASE_URL = "http://report.mcstats.org";
/*     */   private static final String REPORT_URL = "/plugin/%s";
/*     */   private static final int PING_INTERVAL = 15;
/*     */   private final Plugin plugin;
/*  91 */   private final Set<Graph> graphs = Collections.synchronizedSet(new HashSet());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final YamlConfiguration configuration;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final File configurationFile;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final String guid;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final boolean debug;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 116 */   private final Object optOutLock = new Object();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 121 */   private volatile BukkitTask task = null;
/*     */   
/*     */   public Metrics(Plugin paramPlugin) {
/* 124 */     if (paramPlugin == null) {
/* 125 */       throw new IllegalArgumentException("Plugin cannot be null");
/*     */     }
/*     */     
/* 128 */     this.plugin = paramPlugin;
/*     */     
/*     */ 
/* 131 */     this.configurationFile = getConfigFile();
/* 132 */     this.configuration = YamlConfiguration.loadConfiguration(this.configurationFile);
/*     */     
/*     */ 
/* 135 */     this.configuration.addDefault("opt-out", Boolean.valueOf(false));
/* 136 */     this.configuration.addDefault("guid", UUID.randomUUID().toString());
/* 137 */     this.configuration.addDefault("debug", Boolean.valueOf(false));
/*     */     
/*     */ 
/* 140 */     if (this.configuration.get("guid", null) == null) {
/* 141 */       this.configuration.options().header("http://mcstats.org").copyDefaults(true);
/* 142 */       this.configuration.save(this.configurationFile);
/*     */     }
/*     */     
/*     */ 
/* 146 */     this.guid = this.configuration.getString("guid");
/* 147 */     this.debug = this.configuration.getBoolean("debug", false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Graph createGraph(String paramString)
/*     */   {
/* 158 */     if (paramString == null) {
/* 159 */       throw new IllegalArgumentException("Graph name cannot be null");
/*     */     }
/*     */     
/*     */ 
/* 163 */     Graph localGraph = new Graph(paramString, null);
/*     */     
/*     */ 
/* 166 */     this.graphs.add(localGraph);
/*     */     
/*     */ 
/* 169 */     return localGraph;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addGraph(Graph paramGraph)
/*     */   {
/* 178 */     if (paramGraph == null) {
/* 179 */       throw new IllegalArgumentException("Graph cannot be null");
/*     */     }
/*     */     
/* 182 */     this.graphs.add(paramGraph);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean start()
/*     */   {
/* 193 */     synchronized (this.optOutLock)
/*     */     {
/* 195 */       if (isOptOut()) {
/* 196 */         return false;
/*     */       }
/*     */       
/*     */ 
/* 200 */       if (this.task != null) {
/* 201 */         return true;
/*     */       }
/*     */       
/*     */ 
/* 205 */       this.task = this.plugin.getServer().getScheduler().runTaskTimerAsynchronously(this.plugin, new Runnable()
/*     */       {
/* 207 */         private boolean firstPost = true;
/*     */         
/*     */         public void run()
/*     */         {
/*     */           try {
/* 212 */             synchronized (Metrics.this.optOutLock)
/*     */             {
/* 214 */               if ((Metrics.this.isOptOut()) && (Metrics.this.task != null)) {
/* 215 */                 Metrics.this.task.cancel();
/* 216 */                 Metrics.this.task = null;
/*     */                 
/* 218 */                 for (Metrics.Graph localGraph : Metrics.this.graphs) {
/* 219 */                   localGraph.onOptOut();
/*     */                 }
/*     */               }
/*     */             }
/*     */             
/*     */ 
/*     */ 
/*     */ 
/* 227 */             Metrics.this.postPlugin(!this.firstPost);
/*     */             
/*     */ 
/*     */ 
/* 231 */             this.firstPost = false;
/*     */           } catch (IOException localIOException) {
/* 233 */             if (Metrics.this.debug) {
/* 234 */               Bukkit.getLogger().log(Level.INFO, "[Metrics] " + localIOException.getMessage());
/*     */             }
/*     */           }
/*     */         }
/* 238 */       }, 0L, 18000L);
/*     */       
/* 240 */       return true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isOptOut()
/*     */   {
/* 250 */     synchronized (this.optOutLock)
/*     */     {
/*     */       try {
/* 253 */         this.configuration.load(getConfigFile());
/*     */       } catch (IOException localIOException) {
/* 255 */         if (this.debug) {
/* 256 */           Bukkit.getLogger().log(Level.INFO, "[Metrics] " + localIOException.getMessage());
/*     */         }
/* 258 */         return true;
/*     */       } catch (InvalidConfigurationException localInvalidConfigurationException) {
/* 260 */         if (this.debug) {
/* 261 */           Bukkit.getLogger().log(Level.INFO, "[Metrics] " + localInvalidConfigurationException.getMessage());
/*     */         }
/* 263 */         return true;
/*     */       }
/* 265 */       return this.configuration.getBoolean("opt-out", false);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void enable()
/*     */   {
/* 276 */     synchronized (this.optOutLock)
/*     */     {
/* 278 */       if (isOptOut()) {
/* 279 */         this.configuration.set("opt-out", Boolean.valueOf(false));
/* 280 */         this.configuration.save(this.configurationFile);
/*     */       }
/*     */       
/*     */ 
/* 284 */       if (this.task == null) {
/* 285 */         start();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void disable()
/*     */   {
/* 297 */     synchronized (this.optOutLock)
/*     */     {
/* 299 */       if (!isOptOut()) {
/* 300 */         this.configuration.set("opt-out", Boolean.valueOf(true));
/* 301 */         this.configuration.save(this.configurationFile);
/*     */       }
/*     */       
/*     */ 
/* 305 */       if (this.task != null) {
/* 306 */         this.task.cancel();
/* 307 */         this.task = null;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public File getConfigFile()
/*     */   {
/* 323 */     File localFile = this.plugin.getDataFolder().getParentFile();
/*     */     
/*     */ 
/* 326 */     return new File(new File(localFile, "PluginMetrics"), "config.yml");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int getOnlinePlayers()
/*     */   {
/*     */     try
/*     */     {
/* 336 */       Method localMethod = Server.class.getMethod("getOnlinePlayers", new Class[0]);
/* 337 */       if (localMethod.getReturnType().equals(Collection.class)) {
/* 338 */         return ((Collection)localMethod.invoke(Bukkit.getServer(), new Object[0])).size();
/*     */       }
/* 340 */       return ((Player[])localMethod.invoke(Bukkit.getServer(), new Object[0])).length;
/*     */     }
/*     */     catch (Exception localException) {
/* 343 */       if (this.debug) {
/* 344 */         Bukkit.getLogger().log(Level.INFO, "[Metrics] " + localException.getMessage());
/*     */       }
/*     */     }
/*     */     
/* 348 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void postPlugin(boolean paramBoolean)
/*     */   {
/* 356 */     PluginDescriptionFile localPluginDescriptionFile = this.plugin.getDescription();
/* 357 */     String str1 = localPluginDescriptionFile.getName();
/* 358 */     boolean bool = Bukkit.getServer().getOnlineMode();
/* 359 */     String str2 = localPluginDescriptionFile.getVersion();
/* 360 */     String str3 = Bukkit.getVersion();
/* 361 */     int i = getOnlinePlayers();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 366 */     StringBuilder localStringBuilder = new StringBuilder(1024);
/* 367 */     localStringBuilder.append('{');
/*     */     
/*     */ 
/* 370 */     appendJSONPair(localStringBuilder, "guid", this.guid);
/* 371 */     appendJSONPair(localStringBuilder, "plugin_version", str2);
/* 372 */     appendJSONPair(localStringBuilder, "server_version", str3);
/* 373 */     appendJSONPair(localStringBuilder, "players_online", Integer.toString(i));
/*     */     
/*     */ 
/* 376 */     String str4 = System.getProperty("os.name");
/* 377 */     String str5 = System.getProperty("os.arch");
/* 378 */     String str6 = System.getProperty("os.version");
/* 379 */     String str7 = System.getProperty("java.version");
/* 380 */     int j = Runtime.getRuntime().availableProcessors();
/*     */     
/*     */ 
/* 383 */     if (str5.equals("amd64")) {
/* 384 */       str5 = "x86_64";
/*     */     }
/*     */     
/* 387 */     appendJSONPair(localStringBuilder, "osname", str4);
/* 388 */     appendJSONPair(localStringBuilder, "osarch", str5);
/* 389 */     appendJSONPair(localStringBuilder, "osversion", str6);
/* 390 */     appendJSONPair(localStringBuilder, "cores", Integer.toString(j));
/* 391 */     appendJSONPair(localStringBuilder, "auth_mode", bool ? "1" : "0");
/* 392 */     appendJSONPair(localStringBuilder, "java_version", str7);
/*     */     
/*     */ 
/* 395 */     if (paramBoolean) {
/* 396 */       appendJSONPair(localStringBuilder, "ping", "1");
/*     */     }
/*     */     
/* 399 */     if (this.graphs.size() > 0) {
/* 400 */       synchronized (this.graphs) {
/* 401 */         localStringBuilder.append(',');
/* 402 */         localStringBuilder.append('"');
/* 403 */         localStringBuilder.append("graphs");
/* 404 */         localStringBuilder.append('"');
/* 405 */         localStringBuilder.append(':');
/* 406 */         localStringBuilder.append('{');
/*     */         
/* 408 */         int k = 1;
/*     */         
/* 410 */         localObject1 = this.graphs.iterator();
/*     */         
/* 412 */         while (((Iterator)localObject1).hasNext()) {
/* 413 */           localObject2 = (Graph)((Iterator)localObject1).next();
/*     */           
/* 415 */           localObject3 = new StringBuilder();
/* 416 */           ((StringBuilder)localObject3).append('{');
/*     */           
/* 418 */           for (localObject5 = ((Graph)localObject2).getPlotters().iterator(); ((Iterator)localObject5).hasNext();) { localObject4 = (Plotter)((Iterator)localObject5).next();
/* 419 */             appendJSONPair((StringBuilder)localObject3, ((Plotter)localObject4).getColumnName(), Integer.toString(((Plotter)localObject4).getValue()));
/*     */           }
/*     */           
/* 422 */           ((StringBuilder)localObject3).append('}');
/*     */           
/* 424 */           if (k == 0) {
/* 425 */             localStringBuilder.append(',');
/*     */           }
/*     */           
/* 428 */           localStringBuilder.append(escapeJSON(((Graph)localObject2).getName()));
/* 429 */           localStringBuilder.append(':');
/* 430 */           localStringBuilder.append((CharSequence)localObject3);
/*     */           
/* 432 */           k = 0;
/*     */         }
/*     */         
/* 435 */         localStringBuilder.append('}');
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 440 */     localStringBuilder.append('}');
/*     */     
/*     */ 
/* 443 */     ??? = new URL("http://report.mcstats.org" + String.format("/plugin/%s", new Object[] { urlEncode(str1) }));
/*     */     
/*     */ 
/*     */ 
/*     */     URLConnection localURLConnection;
/*     */     
/*     */ 
/* 450 */     if (isMineshafterPresent()) {
/* 451 */       localURLConnection = ((URL)???).openConnection(Proxy.NO_PROXY);
/*     */     } else {
/* 453 */       localURLConnection = ((URL)???).openConnection();
/*     */     }
/*     */     
/*     */ 
/* 457 */     Object localObject1 = localStringBuilder.toString().getBytes();
/* 458 */     Object localObject2 = gzip(localStringBuilder.toString());
/*     */     
/*     */ 
/* 461 */     localURLConnection.addRequestProperty("User-Agent", "MCStats/7");
/* 462 */     localURLConnection.addRequestProperty("Content-Type", "application/json");
/* 463 */     localURLConnection.addRequestProperty("Content-Encoding", "gzip");
/* 464 */     localURLConnection.addRequestProperty("Content-Length", Integer.toString(localObject2.length));
/* 465 */     localURLConnection.addRequestProperty("Accept", "application/json");
/* 466 */     localURLConnection.addRequestProperty("Connection", "close");
/*     */     
/* 468 */     localURLConnection.setDoOutput(true);
/*     */     
/* 470 */     if (this.debug) {
/* 471 */       System.out.println("[Metrics] Prepared request for " + str1 + " uncompressed=" + localObject1.length + " compressed=" + localObject2.length);
/*     */     }
/*     */     
/*     */ 
/* 475 */     Object localObject3 = localURLConnection.getOutputStream();
/* 476 */     ((OutputStream)localObject3).write((byte[])localObject2);
/* 477 */     ((OutputStream)localObject3).flush();
/*     */     
/*     */ 
/* 480 */     Object localObject4 = new BufferedReader(new InputStreamReader(localURLConnection.getInputStream()));
/* 481 */     Object localObject5 = ((BufferedReader)localObject4).readLine();
/*     */     
/*     */ 
/* 484 */     ((OutputStream)localObject3).close();
/* 485 */     ((BufferedReader)localObject4).close();
/*     */     
/* 487 */     if ((localObject5 == null) || (((String)localObject5).startsWith("ERR")) || (((String)localObject5).startsWith("7"))) {
/* 488 */       if (localObject5 == null) {
/* 489 */         localObject5 = "null";
/* 490 */       } else if (((String)localObject5).startsWith("7")) {
/* 491 */         localObject5 = ((String)localObject5).substring(((String)localObject5).startsWith("7,") ? 2 : 1);
/*     */       }
/*     */       
/* 494 */       throw new IOException((String)localObject5);
/*     */     }
/*     */     
/* 497 */     if ((((String)localObject5).equals("1")) || (((String)localObject5).contains("This is your first update this hour"))) {
/* 498 */       synchronized (this.graphs) {
/* 499 */         Iterator localIterator1 = this.graphs.iterator();
/*     */         Iterator localIterator2;
/* 501 */         for (; localIterator1.hasNext(); 
/*     */             
/*     */ 
/* 504 */             localIterator2.hasNext())
/*     */         {
/* 502 */           Graph localGraph = (Graph)localIterator1.next();
/*     */           
/* 504 */           localIterator2 = localGraph.getPlotters().iterator(); continue;Plotter localPlotter = (Plotter)localIterator2.next();
/* 505 */           localPlotter.reset();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public static byte[] gzip(String paramString)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 553	java/io/ByteArrayOutputStream
/*     */     //   3: dup
/*     */     //   4: invokespecial 554	java/io/ByteArrayOutputStream:<init>	()V
/*     */     //   7: astore_1
/*     */     //   8: aconst_null
/*     */     //   9: astore_2
/*     */     //   10: new 556	java/util/zip/GZIPOutputStream
/*     */     //   13: dup
/*     */     //   14: aload_1
/*     */     //   15: invokespecial 559	java/util/zip/GZIPOutputStream:<init>	(Ljava/io/OutputStream;)V
/*     */     //   18: astore_2
/*     */     //   19: aload_2
/*     */     //   20: aload_0
/*     */     //   21: ldc_w 561
/*     */     //   24: invokevirtual 563	java/lang/String:getBytes	(Ljava/lang/String;)[B
/*     */     //   27: invokevirtual 564	java/util/zip/GZIPOutputStream:write	([B)V
/*     */     //   30: goto +42 -> 72
/*     */     //   33: astore_3
/*     */     //   34: aload_3
/*     */     //   35: invokevirtual 567	java/io/IOException:printStackTrace	()V
/*     */     //   38: aload_2
/*     */     //   39: ifnull +46 -> 85
/*     */     //   42: aload_2
/*     */     //   43: invokevirtual 568	java/util/zip/GZIPOutputStream:close	()V
/*     */     //   46: goto +39 -> 85
/*     */     //   49: astore 5
/*     */     //   51: goto +34 -> 85
/*     */     //   54: astore 4
/*     */     //   56: aload_2
/*     */     //   57: ifnull +12 -> 69
/*     */     //   60: aload_2
/*     */     //   61: invokevirtual 568	java/util/zip/GZIPOutputStream:close	()V
/*     */     //   64: goto +5 -> 69
/*     */     //   67: astore 5
/*     */     //   69: aload 4
/*     */     //   71: athrow
/*     */     //   72: aload_2
/*     */     //   73: ifnull +12 -> 85
/*     */     //   76: aload_2
/*     */     //   77: invokevirtual 568	java/util/zip/GZIPOutputStream:close	()V
/*     */     //   80: goto +5 -> 85
/*     */     //   83: astore 5
/*     */     //   85: aload_1
/*     */     //   86: invokevirtual 571	java/io/ByteArrayOutputStream:toByteArray	()[B
/*     */     //   89: areturn
/*     */     // Line number table:
/*     */     //   Java source line #520	-> byte code offset #0
/*     */     //   Java source line #521	-> byte code offset #8
/*     */     //   Java source line #524	-> byte code offset #10
/*     */     //   Java source line #525	-> byte code offset #19
/*     */     //   Java source line #526	-> byte code offset #30
/*     */     //   Java source line #527	-> byte code offset #34
/*     */     //   Java source line #529	-> byte code offset #38
/*     */     //   Java source line #530	-> byte code offset #42
/*     */     //   Java source line #531	-> byte code offset #46
/*     */     //   Java source line #528	-> byte code offset #54
/*     */     //   Java source line #529	-> byte code offset #56
/*     */     //   Java source line #530	-> byte code offset #60
/*     */     //   Java source line #531	-> byte code offset #64
/*     */     //   Java source line #533	-> byte code offset #69
/*     */     //   Java source line #529	-> byte code offset #72
/*     */     //   Java source line #530	-> byte code offset #76
/*     */     //   Java source line #531	-> byte code offset #80
/*     */     //   Java source line #535	-> byte code offset #85
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	90	0	paramString	String
/*     */     //   7	79	1	localByteArrayOutputStream	java.io.ByteArrayOutputStream
/*     */     //   9	68	2	localGZIPOutputStream	java.util.zip.GZIPOutputStream
/*     */     //   33	2	3	localIOException1	IOException
/*     */     //   54	16	4	localObject	Object
/*     */     //   49	1	5	localIOException2	IOException
/*     */     //   67	1	5	localIOException3	IOException
/*     */     //   83	1	5	localIOException4	IOException
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   10	30	33	java/io/IOException
/*     */     //   42	46	49	java/io/IOException
/*     */     //   10	38	54	finally
/*     */     //   60	64	67	java/io/IOException
/*     */     //   76	80	83	java/io/IOException
/*     */   }
/*     */   
/*     */   private boolean isMineshafterPresent()
/*     */   {
/*     */     try
/*     */     {
/* 545 */       Class.forName("mineshafter.MineServer");
/* 546 */       return true;
/*     */     } catch (Exception localException) {}
/* 548 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void appendJSONPair(StringBuilder paramStringBuilder, String paramString1, String paramString2)
/*     */   {
/* 561 */     int i = 0;
/*     */     try
/*     */     {
/* 564 */       if ((paramString2.equals("0")) || (!paramString2.endsWith("0"))) {
/* 565 */         Double.parseDouble(paramString2);
/* 566 */         i = 1;
/*     */       }
/*     */     } catch (NumberFormatException localNumberFormatException) {
/* 569 */       i = 0;
/*     */     }
/*     */     
/* 572 */     if (paramStringBuilder.charAt(paramStringBuilder.length() - 1) != '{') {
/* 573 */       paramStringBuilder.append(',');
/*     */     }
/*     */     
/* 576 */     paramStringBuilder.append(escapeJSON(paramString1));
/* 577 */     paramStringBuilder.append(':');
/*     */     
/* 579 */     if (i != 0) {
/* 580 */       paramStringBuilder.append(paramString2);
/*     */     } else {
/* 582 */       paramStringBuilder.append(escapeJSON(paramString2));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String escapeJSON(String paramString)
/*     */   {
/* 593 */     StringBuilder localStringBuilder = new StringBuilder();
/*     */     
/* 595 */     localStringBuilder.append('"');
/* 596 */     for (int i = 0; i < paramString.length(); i++) {
/* 597 */       char c = paramString.charAt(i);
/*     */       
/* 599 */       switch (c) {
/*     */       case '"': 
/*     */       case '\\': 
/* 602 */         localStringBuilder.append('\\');
/* 603 */         localStringBuilder.append(c);
/* 604 */         break;
/*     */       case '\b': 
/* 606 */         localStringBuilder.append("\\b");
/* 607 */         break;
/*     */       case '\t': 
/* 609 */         localStringBuilder.append("\\t");
/* 610 */         break;
/*     */       case '\n': 
/* 612 */         localStringBuilder.append("\\n");
/* 613 */         break;
/*     */       case '\r': 
/* 615 */         localStringBuilder.append("\\r");
/* 616 */         break;
/*     */       default: 
/* 618 */         if (c < ' ') {
/* 619 */           String str = "000" + Integer.toHexString(c);
/* 620 */           localStringBuilder.append("\\u" + str.substring(str.length() - 4));
/*     */         } else {
/* 622 */           localStringBuilder.append(c);
/*     */         }
/*     */         break;
/*     */       }
/*     */     }
/* 627 */     localStringBuilder.append('"');
/*     */     
/* 629 */     return localStringBuilder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String urlEncode(String paramString)
/*     */   {
/* 639 */     return URLEncoder.encode(paramString, "UTF-8");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Graph
/*     */   {
/*     */     private final String name;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 656 */     private final Set<Metrics.Plotter> plotters = new LinkedHashSet();
/*     */     
/*     */     private Graph(String paramString) {
/* 659 */       this.name = paramString;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getName()
/*     */     {
/* 668 */       return this.name;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void addPlotter(Metrics.Plotter paramPlotter)
/*     */     {
/* 677 */       this.plotters.add(paramPlotter);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void removePlotter(Metrics.Plotter paramPlotter)
/*     */     {
/* 686 */       this.plotters.remove(paramPlotter);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Set<Metrics.Plotter> getPlotters()
/*     */     {
/* 695 */       return Collections.unmodifiableSet(this.plotters);
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 700 */       return this.name.hashCode();
/*     */     }
/*     */     
/*     */     public boolean equals(Object paramObject)
/*     */     {
/* 705 */       if (!(paramObject instanceof Graph)) {
/* 706 */         return false;
/*     */       }
/*     */       
/* 709 */       Graph localGraph = (Graph)paramObject;
/* 710 */       return localGraph.name.equals(this.name);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void onOptOut() {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static abstract class Plotter
/*     */   {
/*     */     private final String name;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Plotter()
/*     */     {
/* 734 */       this("Default");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Plotter(String paramString)
/*     */     {
/* 743 */       this.name = paramString;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public abstract int getValue();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getColumnName()
/*     */     {
/* 761 */       return this.name;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void reset() {}
/*     */     
/*     */ 
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 772 */       return getColumnName().hashCode();
/*     */     }
/*     */     
/*     */     public boolean equals(Object paramObject)
/*     */     {
/* 777 */       if (!(paramObject instanceof Plotter)) {
/* 778 */         return false;
/*     */       }
/*     */       
/* 781 */       Plotter localPlotter = (Plotter)paramObject;
/* 782 */       return (localPlotter.name.equals(this.name)) && (localPlotter.getValue() == getValue());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Brad\Desktop\Decompiler\MoneyMobs(2).jar!\me\venom\moneymobs\metrics\Metrics.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */